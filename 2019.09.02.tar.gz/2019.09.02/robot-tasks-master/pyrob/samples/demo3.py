#!/usr/bin/python3

from pyrob.api import *


@task
def example1():

    for i in range(9):
        move_right()
        move_down()

        if i == 6:
            z = 1 / 0


if __name__ == '__main__':
    run_tasks()

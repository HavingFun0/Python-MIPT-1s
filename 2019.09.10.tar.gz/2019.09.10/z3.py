import turtle
t=turtle

a=100 #длина стороны фигуры
angle=90 #Угол фигуры 
t.shape('turtle')
for i in range(4):
	t.forward(100)
	t.left(90)
input()

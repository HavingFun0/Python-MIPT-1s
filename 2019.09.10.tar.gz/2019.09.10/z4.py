

import turtle
turtle.shape('turtle')

t=turtle

n=100 #количество углов
speedt=4 #скорость черепахи
t.shape('turtle')
while 1:
        t.speed(10)
        t.forward(speedt)
        t.left(360/n)


import turtle
t=turtle

t.shape('turtle')
k=2 #коэффицент увеличения шага
a=1 #начальная длина шага
angle=90 #сторона фигуры 
while 1:
	t.forward(a*k)
	t.left(angle)
	k+=5




